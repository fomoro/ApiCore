﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Incidencias.WebApi.Enum
{
    public enum EstatusProyecto
    {
        Inactivo = 0,
        Activo = 1
    }
}
