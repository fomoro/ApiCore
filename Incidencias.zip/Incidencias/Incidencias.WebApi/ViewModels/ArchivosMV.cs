﻿using Incidencias.Modelos.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Incidencias.WebApi.ViewModels
{
    public class ArchivosMV
    {                
        public string URL { get; set; }
        public string Proveedor { get; set; }
    }

}
