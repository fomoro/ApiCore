﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Incidencias.WebApi.ViewModels
{
    public class LoginVM
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
