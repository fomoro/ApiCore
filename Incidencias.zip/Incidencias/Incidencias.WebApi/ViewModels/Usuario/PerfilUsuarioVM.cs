﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Incidencias.WebApi.ViewModels
{
    public class PerfilUsuarioVM
    {
        public int Id { get; set; }
        public int PerfilId { get; set; }
    }
}
