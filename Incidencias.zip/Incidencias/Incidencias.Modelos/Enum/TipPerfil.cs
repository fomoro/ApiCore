﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Incidencias.Modelos.Enum
{
    public enum TipPerfil
    {
        Administrador = 1,
        Desarrollador = 2,
        Tester = 3
    }
}
