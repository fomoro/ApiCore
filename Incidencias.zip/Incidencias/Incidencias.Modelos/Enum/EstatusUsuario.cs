﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Incidencias.Modelos.Enum
{
    public enum EstatusUsuario
    {
        Inactivo=0,
        Activo=1
    }
}
