using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Incidencias.PruebasUnitarias
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
