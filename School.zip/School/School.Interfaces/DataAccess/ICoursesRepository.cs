﻿

using School.DomainObjects;

namespace School.Interfaces.DataAccess
{
    public interface ICoursesRepository : IRepositoryBase<Course>
    {

    }
}
